/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   info.h
 * Author: luciamarock
 *
 * Created on 5 novembre 2020, 13.14
 */

#ifndef INFO_H
#define INFO_H
void p_info();


#endif /* INFO_H */


